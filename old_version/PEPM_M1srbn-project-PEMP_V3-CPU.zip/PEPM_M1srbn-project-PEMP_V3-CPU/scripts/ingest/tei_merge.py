#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
import xml.etree.ElementTree as ET

from scripts.common.logging import get_logger
from scripts.common.tei import TEI_NS, TEI, write, parse, iter_docs

log = get_logger("ingest.tei_merge")


def main():
    ap = argparse.ArgumentParser(description="Fusionne plusieurs TEI/teiCorpus en un teiCorpus.")
    ap.add_argument("--inputs", nargs="+", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    corpus = ET.Element(f"{{{TEI_NS}}}teiCorpus")
    total = 0
    for inp in args.inputs:
        if not inp.exists():
            log.warning("Fichier manquant: %s (ignoré)", inp)
            continue
        r = parse(inp).getroot()
        for tei in iter_docs(r):
            corpus.append(tei)
            total += 1

    write(corpus, args.out)
    log.info("Écrit %s (%d TEI).", args.out, total)


if __name__ == "__main__":
    main()

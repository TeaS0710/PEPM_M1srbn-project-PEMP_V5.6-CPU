#!/usr/bin/env python3
"""
Utilitaires TEI communs.

- Parse/écriture TEI
- Itération <TEI> / <teiCorpus>
- Helpers <keywords>/<term> (modality, source, etc.)
- Extraction de texte <text>/<body>
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional, Sequence
import xml.etree.ElementTree as ET

TEI_NS = "http://www.tei-c.org/ns/1.0"
TEI = f"{{{TEI_NS}}}"
TEI_TAG = f"{TEI}TEI"
NS = {"tei": TEI_NS}


# --- Parse / write -----------------------------------------------------------

def parse(path: Path | str) -> ET.ElementTree:
    return ET.parse(str(path))

def write(root: ET.Element, out: Path | str) -> None:
    ET.ElementTree(root).write(str(out), encoding="utf-8", xml_declaration=True)

def is_tei(el: ET.Element) -> bool:
    return el.tag.endswith("TEI")

def iter_docs(root: ET.Element) -> Iterable[ET.Element]:
    if is_tei(root):
        yield root
    else:
        for tei in root.findall(".//tei:TEI", NS):
            yield tei


# --- Texte -------------------------------------------------------------------

def extract_body_text(root: ET.Element, tags: Sequence[str] = ("p", "seg", "s", "l")) -> str:
    body = root.find("tei:text/tei:body", NS)
    if body is None:
        return ""
    parts: list[str] = []
    for el in body.iter():
        if not el.text:
            continue
        local = el.tag.split("}")[-1]
        if local in tags:
            t = el.text.strip()
            if t:
                parts.append(t)
    return " ".join(parts)


# --- <keywords>/<term> helpers -----------------------------------------------

def _ensure_keywords(root: ET.Element) -> ET.Element:
    header = root.find("tei:teiHeader", NS)
    if header is None:
        header = ET.SubElement(root, f"{TEI}teiHeader")
    profile = header.find("tei:profileDesc", NS)
    if profile is None:
        profile = ET.SubElement(header, f"{TEI}profileDesc")
    text_class = profile.find("tei:textClass", NS)
    if text_class is None:
        text_class = ET.SubElement(profile, f"{TEI}textClass")
    keywords = text_class.find("tei:keywords", NS)
    if keywords is None:
        keywords = ET.SubElement(text_class, f"{TEI}keywords")
    return keywords

def set_keyword(root: ET.Element, term_type: str, value: str) -> None:
    value = (value or "").strip()
    if not value:
        return
    keywords = _ensure_keywords(root)
    for term in keywords.findall("tei:term", NS):
        if term.get("type") == term_type:
            term.text = value
            return
    t = ET.SubElement(keywords, f"{TEI}term")
    t.set("type", term_type)
    t.text = value

def get_keyword(root: ET.Element, term_type: str) -> Optional[str]:
    keywords = root.find(".//tei:keywords", NS)
    if keywords is None:
        return None
    for term in keywords.findall("tei:term", NS):
        if term.get("type") == term_type:
            if term.text is None:
                return None
            v = term.text.strip()
            return v if v else None
    return None


# --- Modalité : uniquement via <term type="modality"> ------------------------

def set_modality(root: ET.Element, value: str) -> None:
    """Source de vérité: <keywords><term type="modality">value</term>."""
    v = (value or "").strip().lower()
    if not v:
        return
    set_keyword(root, "modality", v)

def get_modality(root: ET.Element) -> Optional[str]:
    v = get_keyword(root, "modality")
    return (v or "").strip().lower() or None


# --- Merge -------------------------------------------------------------------

def merge_corpora(inputs: list[Path | str], out: Path | str) -> None:
    corpus = ET.Element(f"{{{TEI_NS}}}teiCorpus")
    for p in map(Path, inputs):
        r = parse(p).getroot()
        if r.tag.endswith("teiCorpus"):
            for tei in r.findall("tei:TEI", NS):
                corpus.append(tei)
        else:
            corpus.append(r)
    write(corpus, out)

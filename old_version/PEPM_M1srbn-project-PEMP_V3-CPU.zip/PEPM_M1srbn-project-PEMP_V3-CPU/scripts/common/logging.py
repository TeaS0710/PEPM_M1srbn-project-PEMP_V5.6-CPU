#!/usr/bin/env python3
"""
Petit wrapper pour obtenir un logger cohérent dans tout le projet.
"""

from __future__ import annotations

import logging
from typing import Optional


def get_logger(name: Optional[str] = None, level: int = logging.INFO) -> logging.Logger:
    """
    Retourne un logger avec un format simple [LEVEL] message.

    - `name` permet de distinguer les modules dans les logs.
    - On évite de multiplier les handlers sur le même logger.
    """
    logger_name = name if name else "pepm"
    logger = logging.getLogger(logger_name)

    if not logger.handlers:
        handler = logging.StreamHandler()
        fmt = logging.Formatter("[%(levelname)s] %(message)s")
        handler.setFormatter(fmt)
        logger.addHandler(handler)

    logger.setLevel(level)
    return logger

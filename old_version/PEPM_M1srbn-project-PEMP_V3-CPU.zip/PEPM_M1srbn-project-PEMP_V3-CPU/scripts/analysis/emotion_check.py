#!/usr/bin/env python3
"""
Analyse très simple des émotions dans un corpus TEI.

- Parcourt les <p> sous <text>/<body>.
- Score la présence de quelques marqueurs (émoticônes, mots-clés).
- Écrit:
  - un CSV par paragraphe (idx, joy, sad, ang, sur)
  - un JSON avec les agrégats.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter
from pathlib import Path

from scripts.common.logging import get_logger
from scripts.common.tei import TEI, parse

log = get_logger("analysis.emotion_check")

LEX = {
    "joy": {"🙂", "😊", "heureux", "joie", "ravi", "content"},
    "sad": {"😢", "triste", "chagrin", "déprimé"},
    "ang": {"😡", "colère", "furieux", "rage"},
    "sur": {"😮", "surpris", "étonné"},
}


def score_text(s: str) -> Counter:
    s_low = s.lower()
    tokens = re.findall(r"\w+|[^\w\s]", s_low, flags=re.U)
    c = Counter()
    for k, vocab in LEX.items():
        for tok in tokens:
            if tok in vocab:
                c[k] += 1
    return c


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tei", type=Path, required=True, help="Corpus TEI d'entrée.")
    ap.add_argument("--out-csv", type=Path, required=True, help="CSV par paragraphe.")
    ap.add_argument("--out-json", type=Path, required=True, help="JSON agrégé.")
    args = ap.parse_args()

    root = parse(args.tei).getroot()
    rows = []
    agg = Counter()

    # Toutes les <p> sous <text>/<body>
    for i, p in enumerate(root.findall(f".//{TEI}text//{TEI}body//{TEI}p")):
        txt = (p.text or "").strip()
        if not txt:
            continue
        sc = score_text(txt)
        agg.update(sc)
        rows.append({"idx": i, **{k: sc.get(k, 0) for k in LEX.keys()}})

    # CSV
    args.out_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.out_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["idx", *LEX.keys()])
        w.writeheader()
        for r in rows:
            w.writerow(r)

    # JSON agrégé
    args.out_json.parent.mkdir(parents=True, exist_ok=True)
    args.out_json.write_text(
        json.dumps(
            {"counts": dict(agg), "n_paragraphs": len(rows)},
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    log.info("Emotion check: %d paragraphs, agg=%s", len(rows), dict(agg))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Stats simples sur le texte d'un corpus TEI.

- Parcourt les <p> sous <text>/<body>.
- Calcule les distributions de longueur (en tokens).
- Sorties:
  - lengths.tsv (idx, n_tokens)
  - summary.json (min, max, moyenne, médiane, total)
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from statistics import mean, median

from scripts.common.logging import get_logger
from scripts.common.tei import TEI, parse

log = get_logger("analysis.input_stats")


def iter_texts(tei_path: Path):
    t = parse(tei_path)
    root = t.getroot()
    for p in root.findall(f".//{TEI}text//{TEI}body//{TEI}p"):
        txt = (p.text or "").strip()
        if txt:
            yield txt


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tei", type=Path, required=True, help="Corpus TEI d'entrée.")
    ap.add_argument(
        "--audio-root",
        type=Path,
        required=False,
        help="(Réservé futur) racine des audios associés.",
    )
    ap.add_argument("--out-dir", type=Path, required=True, help="Dossier de sortie.")
    args = ap.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)

    lengths = [len(t.split()) for t in iter_texts(args.tei)]
    total = len(lengths)
    log.info("Found %d paragraphs with text.", total)

    # lengths.tsv
    with (args.out_dir / "lengths.tsv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(["idx", "n_tokens"])
        for i, n in enumerate(lengths):
            w.writerow([i, n])

    # summary.json
    summary = {
        "n_paragraphs": total,
        "tokens_sum": sum(lengths),
        "tokens_mean": float(mean(lengths)) if lengths else 0.0,
        "tokens_median": float(median(lengths)) if lengths else 0.0,
        "tokens_min": min(lengths) if lengths else 0,
        "tokens_max": max(lengths) if lengths else 0,
    }
    (args.out_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    log.info(
        "Wrote %s and %s",
        args.out_dir / "lengths.tsv",
        args.out_dir / "summary.json",
    )


if __name__ == "__main__":
    main()

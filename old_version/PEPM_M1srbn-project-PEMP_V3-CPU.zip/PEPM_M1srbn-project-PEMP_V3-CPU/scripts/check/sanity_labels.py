#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from collections import Counter
from pathlib import Path

from scripts.common.logging import get_logger

log = get_logger("check.sanity_labels")


def main():
    ap = argparse.ArgumentParser(description="Sanity: TSV id/label/text doit avoir >= N labels.")
    ap.add_argument("--tsv", type=Path, required=True)
    ap.add_argument("--min-labels", type=int, default=2)
    args = ap.parse_args()

    if not args.tsv.exists():
        raise SystemExit(f"Introuvable: {args.tsv}")

    with args.tsv.open("r", encoding="utf-8") as f:
        rdr = csv.reader(f, delimiter="\t")
        try:
            header = next(rdr)
        except StopIteration:
            log.error("TSV vide: %s", args.tsv)
            raise SystemExit(2)
        cols = [h.strip().lower() for h in header]
        if "label" not in cols:
            log.error("Colonne 'label' manquante (header: %r)", header)
            raise SystemExit(2)
        label_idx = cols.index("label")

        counts = Counter()
        for row in rdr:
            if not row or len(row) <= label_idx:
                continue
            lab = (row[label_idx] or "").strip()
            if lab:
                counts[lab] += 1

    n_labels = len(counts)
    log.info("Répartition labels: %s", dict(counts))
    if n_labels < args.min_labels:
        log.error("Trop peu de labels distincts: %d (min: %d)", n_labels, args.min_labels)
        raise SystemExit(2)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Évalue un modèle spaCy textcat sur un corpus DocBin.

- Charge un modèle depuis --model-dir
- Évalue sur un dossier DocBin (partXXXX.spacy) donné par --spacy-dir
- Si --out-json est fourni, écrit les métriques spaCy dans ce fichier JSON.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import spacy
from spacy.cli.evaluate import evaluate as spacy_evaluate

from scripts.common.logging import get_logger

log = get_logger("evaluate.spacy_stream")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--model-dir",
        type=Path,
        required=True,
        help="Dossier du modèle spaCy (model-best ou model-last).",
    )
    ap.add_argument(
        "--spacy-dir",
        type=Path,
        required=True,
        help="Dossier DocBin (partXXXX.spacy) pour l'évaluation.",
    )
    ap.add_argument(
        "--out-json",
        type=Path,
        default=None,
        help="(Optionnel) Chemin du fichier JSON où écrire les métriques spaCy.",
    )
    args = ap.parse_args()

    if not args.model_dir.exists():
        raise SystemExit(f"Modèle introuvable: {args.model_dir}")
    if not args.spacy_dir.exists():
        raise SystemExit(f"Dossier DocBin introuvable: {args.spacy_dir}")

    log.info("Chargement du modèle spaCy: %s", args.model_dir)
    nlp = spacy.load(str(args.model_dir))

    if args.out_json:
        args.out_json.parent.mkdir(parents=True, exist_ok=True)
        log.info("Évaluation spaCy avec export JSON → %s", args.out_json)
        spacy_evaluate(nlp, str(args.spacy_dir), output=str(args.out_json))
    else:
        log.info("Évaluation spaCy (stdout uniquement)")
        spacy_evaluate(nlp, str(args.spacy_dir))


if __name__ == "__main__":
    main()

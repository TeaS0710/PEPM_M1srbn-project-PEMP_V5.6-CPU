#!/usr/bin/env python3
"""
Agrège des rapports JSON de métriques en un CSV "file,score".

- Cherche un score principal dans chaque JSON:
  - 'score'
  - 'best_score'
  - 'metrics.eval_macro_f1'
  - 'cats_macro_f1'
  - 'macro avg'['f1-score'] (rapport sklearn)
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict

from scripts.common.logging import get_logger

log = get_logger("evaluate.metrics_aggregate")


def extract_score(j: Dict[str, Any]) -> float | None:
    """
    Essaie d'extraire un score principal générique depuis un JSON de métriques.
    Retourne un float ou None si rien ne colle.
    """
    # HF baseline: metrics.eval_macro_f1 ou best_score
    metrics = j.get("metrics")
    if isinstance(metrics, dict) and "eval_macro_f1" in metrics:
        return float(metrics["eval_macro_f1"])

    # Clé directe 'score' ou 'best_score'
    for key in ("score", "best_score", "cats_macro_f1"):
        if key in j:
            try:
                return float(j[key])
            except Exception:
                pass

    # Rapport sklearn: classification_report(output_dict=True)
    if "macro avg" in j:
        macro = j["macro avg"]
        if isinstance(macro, dict) and "f1-score" in macro:
            try:
                return float(macro["f1-score"])
            except Exception:
                pass

    return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--reports-dir",
        type=Path,
        required=True,
        help="Dossier contenant les JSON de rapports (HF, sklearn, spaCy...).",
    )
    ap.add_argument(
        "--out-csv",
        type=Path,
        required=True,
        help="Fichier CSV de sortie.",
    )
    args = ap.parse_args()

    rows = []
    for p in sorted(args.reports_dir.glob("*.json")):
        try:
            j = json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            log.warning("Impossible de lire %s: %s", p, e)
            continue

        sc = extract_score(j)
        if sc is None:
            log.warning("Aucun score principal trouvé dans %s", p)
            continue

        rows.append((p.name, sc))

    args.out_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.out_csv.open("w", encoding="utf-8") as f:
        f.write("file,score\n")
        for name, sc in rows:
            f.write(f"{name},{sc}\n")

    log.info("Agrégation terminée: %s (lignes=%d)", args.out_csv, len(rows))


if __name__ == "__main__":
    main()

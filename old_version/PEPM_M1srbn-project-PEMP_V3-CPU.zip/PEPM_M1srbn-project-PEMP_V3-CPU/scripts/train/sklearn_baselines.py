#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from scripts.common.logging import get_logger

from sklearn.pipeline import make_pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, accuracy_score


log = get_logger("train.sklearn_baselines")


def load_tsv(p: Path):
    X, y = [], []
    with p.open("r", encoding="utf-8") as f:
        rdr = csv.reader(f, delimiter="\t")
        try:
            header = next(rdr)
        except StopIteration:
            return X, y
        cols = [h.strip().lower() for h in header]
        try:
            label_idx = cols.index("label")
            text_idx = cols.index("text")
        except ValueError:
            raise SystemExit(f"{p} doit contenir 'label' et 'text' (header: {header})")
        for row in rdr:
            if not row or len(row) <= max(label_idx, text_idx):
                continue
            lab = (row[label_idx] or "").strip()
            txt = (row[text_idx] or "").strip()
            if lab and txt:
                y.append(lab)
                X.append(txt)
    return X, y


def main():
    ap = argparse.ArgumentParser(description="Sklearn baselines (lecture TSV par header).")
    ap.add_argument("--train", type=Path, required=True)
    ap.add_argument("--dev", type=Path, required=True)
    ap.add_argument("--job", type=Path, required=True)
    ap.add_argument("--models", type=str, default="linear_svm,logreg,sgd")
    ap.add_argument("--unsup", type=str, default="")
    ap.add_argument("--reports", type=Path, required=True)
    ap.add_argument("--outdir", type=Path, required=True)
    args = ap.parse_args()

    Xtr, ytr = load_tsv(args.train)
    Xdv, ydv = load_tsv(args.dev)
    args.reports.mkdir(parents=True, exist_ok=True)
    args.outdir.mkdir(parents=True, exist_ok=True)

    # Baselines minimalistes (ex: LinearSVC + LogisticRegression)
    res = {}
    for name in [m.strip() for m in args.models.split(",") if m.strip()]:
        if name == "linear_svm":
            clf = make_pipeline(TfidfVectorizer(), LinearSVC())
        elif name == "logreg":
            clf = make_pipeline(TfidfVectorizer(), LogisticRegression(max_iter=1000))
        elif name == "sgd":
            from sklearn.linear_model import SGDClassifier
            clf = make_pipeline(TfidfVectorizer(), SGDClassifier(loss="log_loss"))
        else:
            log.warning("Modèle inconnu: %s (ignoré)", name)
            continue

        clf.fit(Xtr, ytr)
        preds = clf.predict(Xdv)
        res[name] = {
            "macro_f1": float(f1_score(ydv, preds, average="macro")),
            "accuracy": float(accuracy_score(ydv, preds)),
        }
        log.info("[%s] macro_f1=%.4f acc=%.4f", name, res[name]["macro_f1"], res[name]["accuracy"])

    (args.reports / "sklearn_report.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()

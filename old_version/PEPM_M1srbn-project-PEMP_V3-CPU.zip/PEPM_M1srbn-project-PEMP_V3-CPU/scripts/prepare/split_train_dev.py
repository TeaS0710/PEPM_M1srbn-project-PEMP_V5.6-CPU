#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import random
from pathlib import Path

from scripts.common.logging import get_logger

log = get_logger("prepare.split_train_dev")


def main():
    ap = argparse.ArgumentParser(description="Split TSV id/label/text en train/dev (header conservé).")
    ap.add_argument("--train-tsv", type=Path, required=True)
    ap.add_argument("--out-train", type=Path, required=True)
    ap.add_argument("--out-dev", type=Path, required=True)
    ap.add_argument("--dev-ratio", type=float, default=0.15)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    if not args.train_tsv.exists():
        raise SystemExit(f"Introuvable: {args.train_tsv}")

    with args.train_tsv.open("r", encoding="utf-8") as f:
        rdr = csv.reader(f, delimiter="\t")
        try:
            header = next(rdr)
        except StopIteration:
            raise SystemExit("TSV vide.")
        rows = [row for row in rdr if row]

    random.seed(args.seed)
    random.shuffle(rows)
    n_dev = int(len(rows) * args.dev_ratio)
    dev = rows[:n_dev]
    train = rows[n_dev:]

    for outp, data in ((args.out_train, train), (args.out_dev, dev)):
        outp.parent.mkdir(parents=True, exist_ok=True)
        with outp.open("w", encoding="utf-8", newline="") as g:
            w = csv.writer(g, delimiter="\t")
            w.writerow(header)  # conserve id,label,text (+ autres colonnes éventuelles)
            w.writerows(data)
        log.info("Écrit %s (%d lignes)", outp, len(data))


if __name__ == "__main__":
    main()

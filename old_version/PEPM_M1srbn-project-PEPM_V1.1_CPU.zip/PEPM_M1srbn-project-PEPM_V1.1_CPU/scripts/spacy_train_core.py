#Projet PEPM By Yi Fan && Adrien
# scripts/spacy_train_core.py
from __future__ import annotations
import argparse
import json
from pathlib import Path
import pathlib
import os
import spacy
from spacy.cli.init_config import init_config
from spacy.cli.train import train as spacy_train
from spacy.util import fix_random_seed
from logging_setup import get_logger

log = get_logger("spacy_train_core")

def _set_exclusive(cfg: dict) -> None:
    try:
        model = cfg["components"]["textcat"]["model"]
        arch = model.get("@architectures", "")
        if "TextCatBOW" in arch:
            model["exclusive_classes"] = True
        elif "TextCatEnsemble" in arch and "linear_model" in model:
            model["linear_model"]["exclusive_classes"] = True
    except Exception:
        pass


def _disable_static_vectors(cfg: dict) -> None:
    try:
        embed = cfg["components"]["tok2vec"]["model"]["embed"]
        if "include_static_vectors" in embed:
            embed["include_static_vectors"] = False
    except Exception:
        pass


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", type=Path, required=True)
    parser.add_argument("--dev", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=42, help="Graine de reproductibilité (défaut: 42)")
    parser.add_argument("--labels", type=Path, help="labels.json généré par build_spacy_corpus.py")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--lang", type=str, default="fr")
    parser.add_argument("--arch", choices=["bow", "cnn"], default="cnn")
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--eval-freq", type=int, default=200)
    parser.add_argument("--batch-start", type=int, default=32)
    parser.add_argument("--batch-stop", type=int, default=512)

    args = parser.parse_args()

    fix_random_seed(args.seed)
    os.environ["PYTHONHASHSEED"] = str(args.seed)
    log.info("Training spaCy text classifier on CPU")

    if args.arch == "bow":
        cfg = init_config(lang=args.lang, pipeline=["textcat"], optimize="efficiency")
    else:
        cfg = init_config(lang=args.lang, pipeline=["textcat"], optimize="accuracy")
        _disable_static_vectors(cfg)

    cfg["training"]["max_epochs"] = max(1, int(args.epochs))
    cfg["training"]["dropout"] = float(args.dropout)
    cfg["training"]["eval_frequency"] = max(50, int(args.eval_freq))
    cfg["training"]["seed"] = int(args.seed)
    cfg["training"]["batcher"] = {
        "@batchers": "spacy.batch_by_padded.v1",
        "discard_oversize": True,
        "buffer": 128,
        "size": {
            "@schedules": "compounding.v1",
            "start": max(1, int(args.batch_start)),
            "stop": max(int(args.batch_start), int(args.batch_stop)),
            "compound": 1.001,
        },
    }
    _set_exclusive(cfg)

    cfg.setdefault("paths", {})
    cfg["paths"]["train"] = str(args.train)
    cfg["paths"]["dev"] = str(args.dev)
    cfg["paths"]["vectors"] = None
    cfg.setdefault("initialize", {})["vectors"] = None

    cfg["training"]["logger"] = {
        "@loggers": "spacy.ConsoleLogger.v1",
        "progress_bar": True,
    }

    labels_path = pathlib.Path(args.labels)  # ex: /tmp/.../labels.json
    if labels_path.exists():
        labels = json.loads(labels_path.read_text())
        # Trouver le composant de catégorisation
        comp_name = next(
            (n for n, c in cfg["components"].items()
            if c.get("@factory") in ("textcat", "textcat_multilabel")),
            None
        )
        if comp_name:
            cfg.setdefault("initialize", {}).setdefault("components", {}).setdefault(comp_name, {})["labels"] = labels


    args.out.mkdir(parents=True, exist_ok=True)
    cfg_path = args.out / "auto_config.cfg"
    cfg.to_disk(cfg_path)
    log.info("Configuration enregistrée dans %s", cfg_path)
    log.debug("training.batcher=%s", json.dumps(cfg["training"]["batcher"], indent=2))

    spacy.require_cpu()
    spacy_train(
        config_path=str(cfg_path),
        output_path=str(args.out),
        use_gpu=-1,
    )


if __name__ == "__main__":
    main()

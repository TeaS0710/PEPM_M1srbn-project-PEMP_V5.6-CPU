#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Extraction TEI (multi-dossiers, multi-process, TEI unique) — version “auto-optimisée”
- Parcourt TOUS les dossiers 'crawl*' sous CRAWLS_ROOT (ou PAGES_DIR si défini)
- Traite TOUTES les pages *.html.gz ET *.html
- Extrait texte & métadonnées (trafilatura) + date (fallbacks), langue, domaine
- Déduplication exacte sur TEXTE (MD5) à l'échelle du corpus
- Ajoute les noms de dossiers (folder_path + folder) dans les keywords TEI
- Écrit UN SEUL fichier TEI: OUT_DIR/corpus.xml (teiCorpus avec un <TEI> par doc)

Optimisations intégrées (aucune variable d’environnement requise):
- Multi-processus (ProcessPoolExecutor) avec N_WORKERS = nombre de cœurs logiques
- Lecture gzip accélérée si la lib Python `isal` est disponible (auto-détection)
- Détection de langue FastText si `fasttext` + modèle `lid.176.ftz` dispo ; sinon fallback langdetect
- Trafilatura avec no_fallback=True (évite les heuristiques lentes)
- map(..., chunksize=K) pour réduire l’overhead du scheduler
"""

from __future__ import annotations
import os, re, sys, gzip, hashlib
from pathlib import Path
from typing import Dict, Tuple, List, Optional, Iterable
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from concurrent.futures import ProcessPoolExecutor

import tldextract
from langdetect import detect, DetectorFactory
import trafilatura
from trafilatura.metadata import extract_metadata
from tqdm import tqdm

# ===================== TEI NS (placer AVANT register_namespace) =====================
TEI_NS = "http://www.tei-c.org/ns/1.0"
ET.register_namespace("", TEI_NS)

# ===================== AUTO-DETECT ACCÉLÉRATEURS =====================

# isal pour (dé)compression gzip très rapide — auto
USE_ISAL = False
try:
    import isal.igzip as igzip  # type: ignore
    USE_ISAL = True
except Exception:
    USE_ISAL = False

# FastText pour la langue — auto si lib + modèle local disponibles
USE_FASTTEXT = False
_FT_MODEL = None
try:
    import fasttext  # type: ignore
    # charge le modèle s’il est présent localement
    _FT_PATH = Path("lid.176.ftz")
    if _FT_PATH.exists():
        _FT_MODEL = fasttext.load_model(str(_FT_PATH))
        USE_FASTTEXT = True
except Exception:
    USE_FASTTEXT = False
    _FT_MODEL = None

# ===================== CONFIG =====================

PAGES_DIR   = ""               # ex: "/home/me/.../crawl-xxx" ; vide => scan auto sous CRAWLS_ROOT
CRAWLS_ROOT = "data"           # racine contenant des dossiers 'crawl*'
CRAWL_NAME_RE = re.compile(r"^crawl[._-].+", re.IGNORECASE)

OUT_DIR     = f"for_txm"
CORPUS_XML  = f"{OUT_DIR}/corpus.xml"

# Filtrage
REQUIRE_CORE = True
ALLOW_PERIPHERY = False
ONLY_FR_SUFFIX = False
ONLY_LANGS: Optional[set[str]] = None  # ex: {'fr'} ou None

# Trafilatura
EXTRACT_KW = dict(
    include_comments=False,
    include_tables=False,
    favor_precision=True,      # mets False si tu veux maximiser le rappel
    include_formatting=False,
)

# Parallélisme (par défaut: tous les cœurs)
N_WORKERS = max(1, (os.cpu_count() or 2))

# Langdetect seed → résultats stables
DetectorFactory.seed = 0

# tldextract pré-compilé (évite réinit inutile)
_TLD = tldextract.TLDExtract(suffix_list_urls=None)

# --- Exécution & confort ---
CHUNKSIZE = 32          # petit => résultats réguliers (adapter 16..64)
DRY_RUN_LIMIT = 5000      # 0 = pas de limite ; sinon ex: 50000 pour tester vite

# ===================== DATES =====================

_DATE_META_NAME_KEYS = [
    r'date', r'pubdate', r'publishdate', r'publish_date', r'created', r'lastmod',
    r'dc.date', r'dc.date.issued', r'article:published_time', r'article:modified_time',
    r'og:published_time', r'og:updated_time',
]
_META_TAG_RE = re.compile(
    r'<meta[^>]+?(?:name|property)\s*=\s*"(?:' + "|".join(_DATE_META_NAME_KEYS) + r')"[^>]+?content\s*=\s*"([^"]+)"',
    re.IGNORECASE
)
_JSONLD_DATE_RE = re.compile(r'"(?:datePublished|dateCreated|dateModified)"\s*:\s*"([^"]+)"', re.IGNORECASE)
_TIME_DT_RE     = re.compile(r'<time[^>]+datetime\s*=\s*"([^"]+)"', re.IGNORECASE)
_ISO_FALLBACK_RE= re.compile(r'(\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}:\d{2}(?:Z|[+\-]\d{2}:?\d{2})?)?)')

# ===================== UTILS =====================

def utc_now_iso() -> str:
    """UTC ISO8601 'YYYY-MM-DDTHH:MM:SSZ' (sans microsecondes)."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

def find_crawl_dirs(root: Path) -> List[Path]:
    if not root.exists():
        return []
    candidates: set[Path] = set()
    # niveau 1
    for p in root.iterdir():
        if p.is_dir() and CRAWL_NAME_RE.match(p.name):
            candidates.add(p)
    # profondeur
    for p in root.rglob("*"):
        if p.is_dir() and CRAWL_NAME_RE.match(p.name):
            candidates.add(p)

    def _has_html_any(d: Path) -> bool:
        try:
            next(d.rglob("*.html"))
            return True
        except StopIteration:
            pass
        try:
            next(d.rglob("*.html.gz"))
            return True
        except StopIteration:
            return False

    crawls: List[Path] = []
    for d in sorted(candidates):
        if _has_html_any(d):
            crawls.append(d)
    return crawls

def iter_html_files(root: Path) -> Iterable[Path]:
    """Itère .html puis .html.gz (pour une meilleure locality disque)."""
    for p in root.rglob("*.html"):
        if p.is_file():
            yield p
    for p in root.rglob("*.html.gz"):
        if p.is_file():
            yield p

def md5_bytes(b: bytes) -> str:
    h = hashlib.md5(); h.update(b); return h.hexdigest()

def _match_any(patterns: List[re.Pattern], s: str) -> bool:
    return any(p.search(s) for p in patterns)

def classify_host(hostname: str, core_patterns, periph_patterns) -> str:
    if _match_any(core_patterns, hostname): return "CORE"
    if _match_any(periph_patterns, hostname): return "PERIPHERY"
    return "CONTEXT"

def split_host(url: str) -> Tuple[str, str, str]:
    ext = _TLD(url or "")
    hostname = ".".join(part for part in (ext.subdomain, ext.domain, ext.suffix) if part).lower()
    regdom   = (f"{ext.domain}.{ext.suffix}" if ext.domain and ext.suffix else "").lower()
    suffix   = (ext.suffix or "").lower()
    return hostname, regdom, suffix

def detect_lang_fast(text: str) -> str:
    if USE_FASTTEXT and _FT_MODEL and text:
        try:
            label, prob = _FT_MODEL.predict(text[:1000])
            if label and prob and prob[0] >= 0.6:
                return label[0].replace("__label__", "")
        except Exception:
            pass
    return ""

def detect_lang_safe(text: str) -> str:
    # FastText d'abord si dispo, sinon langdetect
    ft = detect_lang_fast(text)
    if ft:
        return ft
    try:
        return detect(text)
    except Exception:
        return ""

def normalize_date_string(s: str) -> str:
    s = s.strip()
    s = re.sub(r'(\d{2}:\d{2}:\d{2})\.\d+', r'\1', s)
    if re.match(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}', s):
        s = s.replace(' ', 'T', 1)
    return s

def extract_best_date(raw_html: bytes, meta_d: dict, report_dt: str) -> Tuple[str, str]:
    # 1) Trafilatura
    if meta_d:
        d = (meta_d.get("date") or "").strip()
        if d: return normalize_date_string(d), "trafilatura"

    try:
        html = raw_html.decode("utf-8", errors="ignore")
    except Exception:
        html = ""

    # 2) <meta ...>
    m = _META_TAG_RE.search(html)
    if m: return normalize_date_string(m.group(1)), "meta"

    # 3) JSON-LD
    m = _JSONLD_DATE_RE.search(html)
    if m: return normalize_date_string(m.group(1)), "jsonld"

    # 4) <time datetime="...">
    m = _TIME_DT_RE.search(html)
    if m: return normalize_date_string(m.group(1)), "time"

    # 5) motif ISO
    m = _ISO_FALLBACK_RE.search(html)
    if m: return normalize_date_string(m.group(1)), "iso"

    # 6) fallback éventuel (si CSV externe un jour)
    if report_dt: return normalize_date_string(report_dt), "report"

    return "unknown", "unknown"

def should_keep(klass: str, suffix: str, lang: str) -> bool:
    if REQUIRE_CORE and klass != "CORE": return False
    if not ALLOW_PERIPHERY and klass == "PERIPHERY": return False
    if ONLY_FR_SUFFIX and suffix not in ("fr",): return False
    if ONLY_LANGS and (lang.split("-")[0] not in ONLY_LANGS): return False
    return True

def paragraphs(text: str) -> List[str]:
    chunks = [p.strip() for p in re.split(r'\n{2,}', text.strip()) if p.strip()]
    if not chunks:
        t = text.strip()
        chunks = [t[i:i+800] for i in range(0, len(t), 800)] if t else []
    return chunks

# ===================== EXTRACTION (WORKER) =====================

def _read_raw(path: Path) -> bytes:
    if path.suffix == ".gz":
        if USE_ISAL:
            with igzip.open(path, "rb") as f:
                return f.read()
        else:
            with gzip.open(path, "rb") as f:
                return f.read()
    else:
        return path.read_bytes()

def process_one(args: Tuple[Path, Path, List[re.Pattern], List[re.Pattern], str, Path]):
    """Worker: lit, extrait, filtre un fichier .html(.gz). Retourne (row_dict | None, reason | None)."""
    src, rel_from, core_patterns, periph_patterns, crawl_name, root_for_meta = args

    rel_path_from_crawl = src.relative_to(rel_from).as_posix()

    # Lire HTML
    try:
        raw = _read_raw(src)
    except Exception as e:
        return None, f"read_error:{e}"

    # Extraction texte + meta (rapide)
    try:
        text = trafilatura.extract(raw, url=None, no_fallback=True, **EXTRACT_KW) or ""
        meta = extract_metadata(raw, default_url=None)
        meta_d = meta.as_dict() if meta else {}
    except Exception as e:
        return None, f"extract_error:{e}"

    if not text.strip():
        return None, "empty"

    # URL si dispo dans meta
    url = (meta_d.get("url") or meta_d.get("sitename") or "").strip()

    # host/class
    hostname, regdom, suffix = split_host(url) if url else ("", "", "")
    klass = classify_host(hostname, core_patterns, periph_patterns)

    # langue (éviter le coût si meta déjà là)
    lang = (meta_d.get("language") or detect_lang_safe(text[:800]) or "").lower()

    # filtres
    if not should_keep(klass, suffix, lang):
        return None, "filtered"

    # titre + date
    title = meta_d.get("title", "") or ""
    published, date_source = extract_best_date(raw, meta_d, report_dt="")

    # === Dossiers → métadonnées
    rel_from_root = src.relative_to(root_for_meta)
    parents = list(rel_from_root.parents)
    if parents:
        parents = parents[:-1]  # drop root itself
    folder_parts = [p.name for p in reversed(parents) if p.name]
    folder_path = "/".join(folder_parts)

    row = {
        "id": "",
        "path": rel_path_from_crawl,
        "url": url,
        "domain": regdom,
        "suffix": suffix,
        "class": klass,
        "crawl": crawl_name,
        "title": title,
        "published": published,
        "date_source": date_source,
        "lang": lang,
        "chars": len(text),
        "md5_html": md5_bytes(raw),
        "text": text,
        "folder_path": folder_path,
        "folders": folder_parts,
    }
    return row, None

# ===================== TEI BUILD =====================

def E(tag: str, text: Optional[str]=None, **attrs):
    el = ET.Element(f"{{{TEI_NS}}}{tag}", {k:str(v) for k,v in attrs.items() if v is not None})
    if text is not None:
        el.text = text
    return el

def build_TEI_doc(row: dict) -> ET.Element:
    tei = E("TEI", **{"xml:id": row["id"]})

    # --- teiHeader ---
    teiHeader = E("teiHeader"); tei.append(teiHeader)

    fileDesc = E("fileDesc"); teiHeader.append(fileDesc)
    titleStmt = E("titleStmt"); fileDesc.append(titleStmt)
    titleTxt = row["title"] or row["id"]
    titleStmt.append(E("title", titleTxt))
    respStmt = E("respStmt"); titleStmt.append(respStmt)
    respStmt.append(E("resp", "Extraction/normalisation"))
    respStmt.append(E("name", "tei-corpus-mp"))

    pubStmt = E("publicationStmt")
    pubStmt.append(E("publisher", "local"))
    pubStmt.append(E("pubPlace", "machine"))
    pubStmt.append(E("date", **{"when": utc_now_iso()}))
    availability = E("availability", **{"status":"restricted"})
    availability.append(E("licence", "internal-use"))
    pubStmt.append(availability)
    fileDesc.append(pubStmt)

    sourceDesc = E("sourceDesc")
    bibl = E("biblStruct")
    if row["url"]: bibl.append(E("idno", row["url"], type="url"))
    bibl.append(E("idno", row["path"], type="path"))
    bibl.append(E("idno", row["md5_html"], type="md5_html"))
    sourceDesc.append(bibl)
    fileDesc.append(sourceDesc)

    profileDesc = E("profileDesc")
    langUsage = E("langUsage")
    if row["lang"]:
        langEl = E("language", row["lang"], ident=row["lang"]) ; langUsage.append(langEl)
    profileDesc.append(langUsage)

    textClass = E("textClass")
    keywords = E("keywords", scheme="custom")
    for k in ("domain","suffix","class","crawl","published","date_source"):
        val = row.get(k) or ""
        if val:
            keywords.append(E("term", val, type=k))
    # Dossiers → keywords
    if row.get("folder_path"):
        keywords.append(E("term", row["folder_path"], type="folder_path"))
    for fname in row.get("folders", []):
        keywords.append(E("term", fname, type="folder"))
    textClass.append(keywords)
    profileDesc.append(textClass)
    teiHeader.append(profileDesc)

    encodingDesc = E("encodingDesc")
    appInfo = E("appInfo")
    appInfo.append(E("application", "trafilatura", version=getattr(trafilatura, "__version__", "unknown")))
    encodingDesc.append(appInfo)
    teiHeader.append(encodingDesc)

    revisionDesc = E("revisionDesc")
    revisionDesc.append(E("change", f"md5_text={row.get('md5_text','')}; chars={row['chars']}"))
    teiHeader.append(revisionDesc)

    # --- text ---
    textEl = E("text", **(({"xml:lang": row["lang"]} if row["lang"] else {})))
    body = E("body"); textEl.append(body)
    div = E("div", type="article"); body.append(div)
    if row["title"]: div.append(E("head", row["title"]))
    for ptxt in paragraphs(row["text"]):
        div.append(E("p", ptxt))
    tei.append(textEl)

    # --- standOff (placeholder) ---
    standOff = E("standOff"); standOff.append(E("listAnnotation")); tei.append(standOff)

    return tei

def write_corpus_tei(all_rows: List[dict], out_path: Path):
    corpus = ET.Element(f"{{{TEI_NS}}}teiCorpus")

    # en-tête corpus
    teiHeader = E("teiHeader")
    fileDesc = E("fileDesc")
    titleStmt = E("titleStmt"); titleStmt.append(E("title", "Corpus TEI (extraction multi-dossiers)"))
    fileDesc.append(titleStmt)
    publicationStmt = E("publicationStmt")
    publicationStmt.append(E("publisher", "local"))
    publicationStmt.append(E("date", **{"when": utc_now_iso()}))
    fileDesc.append(publicationStmt)
    sourceDesc = E("sourceDesc")
    sourceDesc.append(E("p", "Sources diverses issues de crawls locaux."))
    fileDesc.append(sourceDesc)
    teiHeader.append(fileDesc)
    corpus.append(teiHeader)

    for row in all_rows:
        corpus.append(build_TEI_doc(row))

    tree = ET.ElementTree(corpus)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    tree.write(out_path.as_posix(), encoding="utf-8", xml_declaration=True)

# ===================== PIPELINE =====================

def collect_jobs() -> List[tuple[Path, Path, str, Path]]:
    """Retourne une liste de tuples (src_file, crawl_dir, crawl_name, root_for_meta)."""
    jobs: List[tuple[Path, Path, str, Path]] = []

    if PAGES_DIR:
        pages_root = Path(PAGES_DIR)
        if not pages_root.exists():
            print(f"[ERR] {PAGES_DIR} introuvable", file=sys.stderr); sys.exit(1)
        crawl_dirs = [pages_root]
        root_for_meta = pages_root
    else:
        root = Path(CRAWLS_ROOT)
        crawl_dirs = find_crawl_dirs(root)
        if not crawl_dirs:
            print(f"[ERR] Aucun dossier 'crawl*' (avec .html/.html.gz) trouvé sous {CRAWLS_ROOT}", file=sys.stderr); sys.exit(1)
        root_for_meta = root

    for crawl_dir in crawl_dirs:
        for f in iter_html_files(crawl_dir):
            jobs.append((f, crawl_dir, crawl_dir.name, root_for_meta))

    return jobs

def dedup_exact(rows: List[dict]):
    seen, uniq, removed = set(), [], 0
    for r in rows:
        h = hashlib.md5(r["text"].encode("utf-8", errors="ignore")).hexdigest()
        if h in seen:
            removed += 1
        else:
            seen.add(h); r["md5_text"] = h; uniq.append(r)
    return uniq, removed

def run():
    core_patterns    = [re.compile(r".*", re.IGNORECASE)]     # tout CORE par défaut
    periph_patterns  = []                                     # vide

    # 1) Collecte des jobs (tous dossiers, tous fichiers)
    jobs = collect_jobs()
    total = len(jobs)
    if total == 0:
        print("[ERR] Aucun .html/.html.gz trouvé.")
        sys.exit(1)

    # 2) Exécution multi-process
    rows: List[dict] = []
    reasons_global: Dict[str, int] = {}
    total_skipped = total_errors = 0

    worker_args = [
        (src, crawl_dir, core_patterns, periph_patterns, crawl_name, root_for_meta)
        for (src, crawl_dir, crawl_name, root_for_meta) in jobs
    ]

    print(f"[INFO] Files: {total} | Workers: {N_WORKERS} | chunksize={CHUNKSIZE}")
    try:
        with ProcessPoolExecutor(max_workers=N_WORKERS) as ex:
            with tqdm(total=total, desc="extract[ALL]", unit="file") as pbar:
                for row, err in ex.map(process_one, worker_args, chunksize=CHUNKSIZE):
                    if row is not None:
                        rows.append(row)
                    else:
                        total_skipped += 1
                        reasons_global[err or "unknown"] = reasons_global.get(err or "unknown", 0) + 1
                        if err and not str(err).startswith(("empty","filtered")):
                            total_errors += 1
                    pbar.update(1)

    except KeyboardInterrupt:
        print("\n[ABORT] Interruption utilisateur: écriture du corpus **partiel**…")

    # 3) Dédup par texte (corpus complet ou partiel)
    if not rows:
        print("[WARN] Aucun document extrait. Rien à écrire.")
        return
    rows, removed = dedup_exact(rows)

    # 4) IDs stables
    for i, r in enumerate(rows):
        r["id"] = f"doc_{i:06d}"

    # 5) Écriture TEI
    write_corpus_tei(rows, Path(CORPUS_XML))

    print(f"[OK] TEI écrit : {Path(CORPUS_XML).resolve()}")
    print(f"[INFO] Docs    : {len(rows)} | Skipped: {total_skipped} | Errors: {total_errors} | Dedup: {removed}")
    print(f"[INFO] Motifs skip: {reasons_global}")
    print("\nTXM → Importer → TEI → sélectionne 'corpus.xml'.")

if __name__ == "__main__":
    run()


#python3 tei_corpus_mp.py

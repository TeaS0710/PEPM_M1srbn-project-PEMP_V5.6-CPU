# Projet PEPM By Yi Fan && Adrien
# Rapport technique — Chaîne d’entraînement texte (TEI → spaCy)

## 1) Objectif & périmètre

Le projet construit une **chaîne reproductible** pour entraîner un **classifieur de textes en français** avec **spaCy**, à partir d’un **corpus TEI** issu de crawls web. La chaîne couvre : **extraction HTML → TEI → split TSV → DocBin (.spacy) → entraînement → évaluation**, avec une forte attention à l’**équilibrage des classes**, à la **maîtrise CPU/RAM** et à la **lecture des métriques** (accuracy vs macro-F1).

---

## 2) Arborescence du dépôt (commenté)

```
.
├── data
│   ├── configs               # Config projet (mappages, rapports)
│   │   ├── actors_counts.tsv
│   │   └── ideology.yml      # Table de mappage source -> {gauche|droite}
│   ├── interim
│   │   └── ideo              # Splits et sous-TEI générés pour la tâche "idéologie"
│   │       ├── corpus_job.xml
│   │       ├── corpus_train.xml
│   │       ├── job.tsv
│   │       └── train.tsv
│   ├── processed
│   │   └── spacy             # Artéfacts spaCy (DocBin + labels)
│   │       ├── ideo_job.spacy
│   │       ├── ideo_labels.json
│   │       └── ideo_train.spacy
│   └── raw
│       ├── corpus
│       │   └── corpus.xml    # Gros TEI consolidé
│       └── crawls            # Crawls HTML sources (origine)
├── logs                      # Journaux d’exécution
├── models
│   └── spacy_ideo
│       ├── auto_config.cfg
│       └── model-last/ ...   # Modèle entraîné (checkpoint final)
├── reports
│   ├── actors_counts.tsv
│   └── ideo_metrics.json     # Résultats d’évaluation
├── scripts                   # Outils Python (prépa, train, éval)
│   ├── tei_to_train_job.py   # TEI -> TSV (split + équilibrage TRAIN, JOB intact)
│   ├── build_spacy_corpus.py # TSV -> DocBin (.spacy) + labels.json
│   ├── spacy_train_core.py   # Entraînement spaCy (CPU)
│   ├── eval_textcat_stream.py# Évaluation streaming (RAM friendly)
│   └── ...
├── Makefile                  # Orchestration (raccourcis reproductibles)
├── README.md                 # Documentation étendue (technique & choix)
└── doc_aditionnel.md         # Notes & procédures RAM-friendly / équilibrage
```

Cette organisation est cohérente avec la structure “conseillée” dans ton README (raw/interim/processed, scripts, models, reports, Makefile), ce qui facilite la **reproductibilité** et l’**hygiène de projet**.

---

## 3) Formats & données : du HTML au TEI, puis au TSV et au DocBin

1. **HTML → TEI (`corpus.xml`)**
   Les pages HTML (et *.html.gz*) sont lues et transformées en **TEI** (un `<TEI>` par document) avec texte + métadonnées (titre, url, date si dispo). On applique une **déduplication exacte** sur le texte (MD5). Des **mots-clés TEI** sont ajoutés (ex. *crawl*, *domain*, etc.). Résultat : **un unique** `teiCorpus.xml`.

2. **TEI → TSV (`train.tsv`, `job.tsv`)**
   On filtre (min de caractères, coupe douce par `max_tokens`), on fait un **split 80/20 stratifié par label** (seed fixe). **Le label** provient soit du champ TEI **`crawl`** (multi-classe), soit d’un **mappage** (ex. `ideology.yml` → *gauche/droite*). **Équilibrage TRAIN uniquement** possible avant apprentissage (voir §6). Le **JOB reste la réalité** (jamais équilibré).

3. **TSV → DocBin (.spacy)**
   Les TSV sont convertis en **DocBin** (binaire compact de spaCy), et on écrit un **`labels.json`** ordonné, utile pour la stabilité des runs. Les limites d’échantillonnage **se font ici** quand on veut des tests rapides (paramètre `--limit`).

---

## 4) Les trois “familles” de jeux

* **`ideo`** : **binaire** *gauche/droite* via `--label-field ideology` + `ideology.yml`.
  ⚠️ Si une source n’est pas mappée dans YAML, son label retombe sur `crawl-*`, ce qui mélange binaire et multiclasses → il faut **compléter `ideology.yml`** si l’on veut strictement 2 classes.

* **`quick`** : **multiclasse** par **source/crawl** (labels = noms de crawls). **Petit/rapide** grâce à `QUICK_LIMIT` et `QUICK_MAX_TOKENS` (prototypage).

* **`full`** : comme `quick` mais sur le **corpus complet** (run “final” plus coûteux).

---

## 5) Pourquoi **Makefile + Bash** au-dessus de Python ?

* **Makefile** orchestre des **recettes reproductibles** : même commandes, mêmes entrées/sorties, **variables** surchargées à la volée (`make VAR=...`), cibles atomiques (prépa, train, éval).
* **Bash** est parfait pour **chaîner** et **borner les ressources** (ex. variables de threads BLAS, evaluation “stream”, wrappers éventuels).
* **Python** reste au cœur du traitement (parser TEI, split, équilibrage, DocBin, entraînement).
  → Le mélange permet d’avoir **la rapidité d’itération** (Make) et la **puissance de transformation** (Python), avec des contrôles CPU/RAM explicites.

---

## 6) Gérer les classes déséquilibrées (TRAIN seulement)

Trois stratégies complémentaires sont implémentées **dans `tei_to_train_job.py`** (et exposées par Make) :

* **`cap_docs`** (*plafond de documents par label*)
  Avec `--oversample`, si `--cap-per-label` ≥ taille de la majoritaire, on **duplique** les minoritaires **sans couper** les majoritaires (équilibrage “sans perte”).

* **`cap_tokens`** (*plafond de tokens par label*)
  Utile si les documents ont des longueurs très différentes (ex. billets vs transcriptions longues).

* **`alpha_total`** (*échantillonnage tempéré*)
  On cible une **taille totale** avec des quotas ∝ `count(label)^alpha` (0<α≤1), ce qui **lisse** sans égaliser brutalement. Peut couper des très grosses classes si `total` est petit.

**Procédure conseillée** (safe) : faire un split **sans équilibrage**, lire les **comptes par label** (logs), prendre **Nmax** (taille de la classe majoritaire du TRAIN), puis relancer avec `cap_docs --oversample --cap-per-label Nmax` pour un **équilibrage sans coupe**.

---

## 7) Entraînement spaCy (CPU)

* **Profils** : `arch=cnn` (tok2vec/CNN, robuste & rapide) et `arch=bow` (TextCatBOW, plus simple, utile en démo).
* **Réglages clés** : batch *compounding* (`batch-start → batch-stop`), `dropout` modéré, `eval_freq` raisonnable, `n_process` cohérent avec les cœurs **et** les threads BLAS.
* **Checkpoints** : `model-last/` = dernier état, `model-best/` = meilleur score DEV. Si `best` manque, l’éval peut **basculer sur `last`** (légère différence possible).

---

## 8) Évaluation & métriques

* **Accuracy** sensible à la **distribution** (peut être trompeuse si le JOB est très déséquilibré).
* **Macro-F1** : moyenne sur les classes → punit les classes rares mal apprises (à privilégier pour lecture “juste”).
* **Weighted-F1** : pondéré par la taille de classe (souvent proche de l’accuracy si les petites classes sont ignorées).
* **Matrice de confusion** : montre les **porosités** (quelles classes se confondent).
* **Baselines honnêtes** : *majoritaire* (souvent “bonne” acc mais macro-F1 basse), *aléatoire 50/50* en binaire (~0.5 F1).

---

## 9) Maîtriser CPU/RAM (conseils pratiques)

* **Limiter les threads** BLAS/OpenMP (déjà exportés par défaut dans le Makefile) et garder `WORKERS` modestes (2–4).
* **Réduire** temporairement `--max-tokens` (coupe douce) pour calmer RAM/temps.
* **Limiter le JOB** pendant l’éval (`JOB_LIMIT`) ou utiliser l’**évaluation streaming** (script `eval_textcat_stream.py`) pour quasi-pas de RAM.
* Si DocBin devient énorme, **segmenter** (écrire plusieurs `.spacy`) ou **réduire** `limit`.
* Penser à **reconstruire le JOB** quand on change `JOB_LIMIT` (sinon l’ancien `job.spacy` est réutilisé).

---

## 10) Commandes utiles (démo binaire “idéologie”)

**Baseline rapide & éval RAM-friendly** :

```bash
# 0) Reset & infos
make clean && make setup && make sysinfo

# 1) Préparation (binaire via ideology.yml) — sans équilibrage
make WORKERS=4 BALANCE=none prepare_ideo

# 2) Entraînement avec checkpoints fréquents (favoriser model-best/)
make WORKERS=4 EVAL_FREQ=1 train_ideo

# 3) Évaluation progressive (échantillon stratifié)
make JOB_LIMIT=500  eval_ideo
make JOB_LIMIT=1000 eval_ideo
make JOB_LIMIT=2000 eval_ideo
# puis, si la machine tient : make JOB_LIMIT=0 eval_ideo   (pleine)
```

Ces séquences proviennent de la section “Séquence SAFE (RAM-friendly)” et des recommandations de reconstruction/échantillonnage.

**Équilibrage TRAIN sans couper** :

```bash
# Lire Nmax sur le TRAIN (compte de la majoritaire)
NMAX=$(awk -F'\t' 'NR>1{c[$$2]++} END{for(k in c){if(c[k]>m)m=c[k]} print m}' data/interim/ideo/train.tsv)

# Relancer la prépa avec duplication des minoritaires
make WORKERS=4 BALANCE=cap_docs CAP_PER_LABEL=$NMAX OVERSAMPLE=--oversample prepare_ideo

# Réentraîner + évaluer
make WORKERS=4 train_ideo
make eval_ideo
```

---

## 11) Dépannage (symptômes courants)

* **Pas de `model-best/`** : l’éval peut **tomber sur `model-last/`** (JSON produit quand même ; scores possiblement un peu “pessimistes” si sur-apprentissage). Solution : **`EVAL_FREQ` faible**, comparer `best` vs `last` si dispo.
* **OOM / lenteur** : baisser `--max-tokens`, limiter `JOB_LIMIT`, threads BLAS=1, utiliser **évaluation streaming**.
* **Une seule classe dans TRAIN** (erreur spaCy sur classes exclusives) : refaire la prépa (augmenter limites, activer équilibrage).
* **Échantillon pas pris en compte** : penser à **reconstruire `job.spacy`** quand `JOB_LIMIT` change (sinon réutilisation de l’ancien fichier).

---

## 12) Pourquoi ces choix “ingénierie de données” ?

* **TEI unique consolidé** : facilite la **déduplication** et les **métadonnées** homogènes.
* **Split stratifié + JOB “intouchable”** : le test reflète le **monde réel** (même s’il est déséquilibré). On n’évalue pas sur un jeu artificiellement “facile”.
* **Équilibrage TRAIN** (avant apprentissage) : améliore l’**apprentissage** sans fausser l’**évaluation**.
* **DocBin spaCy** : format compact/rapide, idéal pour l’entraînement répétable.
* **Makefile** : **industrialise** les runs, centralise les paramètres, et documente implicitement le “comment faire”.

---

## 13) Glossaire express

* **TEI** : format XML académique pour représenter des textes et leurs métadonnées.
* **TSV** : table *tab-separated values* ; ici colonnes `text`, `label`.
* **DocBin** : binaire spaCy pour stocker efficacement des documents.
* **tok2vec / CNN / BOW** : composants d’encodage texte dans spaCy (réseaux conv. vs sac de mots).
* **Accuracy / Macro-F1 / Weighted-F1** : métriques de classification ; **macro-F1** valorise l’équité entre classes.

---

## 14) Pour aller plus loin (pistes)

* **Compléter `ideology.yml`** pour garantir une **binaire propre** (éviter les labels `crawl-*`).
* Tester d’autres stratégies d’équilibrage (`cap_tokens`, `alpha_total`) selon l’hétérogénéité des longueurs.
* Ajouter une cible Make `eval_ideo_stream` systématique pour les grosses évaluations **RAM-friendly**.

---

### TL;DR (résumé opérationnel)

1. **Prépare** (`prepare_ideo/quick/full`) → 2) **Entraîne** (`train_*`) → 3) **Évalue** (`eval_*`).
   Toujours **équilibrer le TRAIN uniquement**, **ne jamais toucher au JOB**, et **caper** CPU/RAM si besoin (threads BLAS, `JOB_LIMIT`, *stream*). Les commandes et réglages suggérés dans tes docs couvrent ces bonnes pratiques.

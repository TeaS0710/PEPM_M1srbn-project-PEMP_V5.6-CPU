#Projet PEPM By Yi Fan && Adrien
#!/usr/bin/env python3
import argparse, hashlib, json, subprocess, platform, sys
from pathlib import Path

def md5file(p:Path):
    h=hashlib.md5()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def gsha():
    try:
        return subprocess.check_output(["git","rev-parse","HEAD"], text=True).strip()
    except Exception:
        return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--files", nargs="*", default=[
        "data/interim/quick/train.tsv",
        "data/interim/quick/job.tsv"
    ])
    ap.add_argument("--out", type=Path, default=Path("reports/run_meta.json"))
    args=ap.parse_args()

    meta = {
        "git_sha": gsha(),
        "python": sys.version,
        "platform": platform.platform(),
        "files_md5": {},
    }
    for f in args.files:
        p=Path(f)
        if p.exists():
            meta["files_md5"][str(p)] = md5file(p)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] meta → {args.out}")

if __name__=="__main__":
    main()

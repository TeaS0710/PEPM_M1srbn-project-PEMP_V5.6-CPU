#!/usr/bin/env python3
import argparse, subprocess, sys, tempfile, csv
from pathlib import Path
from typing import Tuple, List

def run(cmd):
    print("[RUN]", *cmd); return subprocess.run(cmd, check=True)

def count_labels(tsv: Path) -> tuple[int, list[tuple[str,int]]]:
    counts = {}
    with tsv.open("r", encoding="utf-8") as f:
        rdr = csv.reader(f, delimiter="\t")
        next(rdr, None)  # header
        for row in rdr:
            if len(row) < 2: continue
            lab = (row[1] or "").strip()
            if not lab: continue
            counts[lab] = counts.get(lab, 0) + 1
    ranked = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    return len(counts), ranked

def split_once(tmpdir: Path, args, offset: int) -> tuple[Path, Path]:
    splits = tmpdir / f"splits_off{offset}"
    cmd = [
        sys.executable, "scripts/tei_to_train_job.py",
        "--corpus", str(args.corpus),
        "--outdir", str(splits),
        "--train-prop", str(args.train_prop),
        "--label-field", args.label_field,
        "--min-chars", str(args.min_chars),
        "--max-tokens", str(args.max_tokens),
        "--limit", str(args.limit),
        "--offset", str(offset),
        "--procs", str(args.procs),
        "--seed", str(args.seed),
        "--modality", args.modality,
    ]
    if args.label_field=="ideology":
        if not args.ideology_map:
            raise SystemExit("⛔ --ideology-map requis quand --label-field=ideology")
        cmd += ["--ideology-map", str(args.ideology_map)]
    run(cmd)
    return splits / "train.tsv", splits / "job.tsv"

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--corpus", type=Path, required=True)
    p.add_argument("--label-field", choices=("crawl","ideology_map"), default="crawl")
    p.add_argument("--modality", choices=("any","web","asr","gold"), default="web")
    p.add_argument("--ideology-map", type=Path, default=None)
    p.add_argument("--limit", type=int, default=30000)
    p.add_argument("--min-chars", type=int, default=150)
    p.add_argument("--max-tokens", type=int, default=400)
    p.add_argument("--train-prop", type=float, default=0.8)
    p.add_argument("--procs", type=int, default=2)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--auto-offset-scan",dest="auto_offset_scan",action="store_true")
    p.add_argument("--scan-step",type=int,default=200000)
    p.add_argument("--scan-max-tries",type=int,default=10)
    args = p.parse_args()

    tmp = Path(tempfile.mkdtemp(prefix="pipeline_check_"))
    print("[TMP]", tmp)
    run([sys.executable, "scripts/sysinfo.py"])
    run([sys.executable, "scripts/check_imports.py"])

    tries = 0
    offset = 0
    while True:
        train, job = split_once(tmp, args, offset)
        nlab, ranked = count_labels(train)
        print(f"[LABELS] distincts={nlab}")
        for lab, c in ranked[:10]:
            print(f"  - {lab}: {c}")
        if not args.auto_offset_scan or nlab >= 2:
            break
        tries += 1
        if tries >= args.scan_max_tries:
            print("[WARN] auto-scan: épuisé sans atteindre >=2 labels")
            break
        offset += args.scan_step
        print(f"[SCAN] essai {tries}/{args.scan_max_tries}, offset -> {offset}")

if __name__ == "__main__":
    main()

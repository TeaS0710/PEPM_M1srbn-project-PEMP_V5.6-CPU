#Projet PEPM By Yi Fan && Adrien
#!/usr/bin/env python3
# scripts/sanity_labels.py
"""
Vérifie qu'un TSV d'entraînement contient au moins N labels distincts
(et, optionnellement, un minimum d'exemples par label). Retour non-zéro si KO.

Exemples:
  python3 scripts/sanity_labels.py --tsv data/interim/ideo_web/train.tsv
  python3 scripts/sanity_labels.py --tsv data/interim/quick_web/train.tsv --min-labels 2 --min-per-label 5
"""

import argparse
import sys
from collections import Counter

import pandas as pd


def guess_label_column(df, explicit: str | None) -> str:
    """Détermine la colonne des labels."""
    if explicit and explicit in df.columns:
        return explicit
    for cand in ("label", "labels", "y", "target"):
        if cand in df.columns:
            return cand
    # fallback: dernière colonne si ≥2 colonnes, sinon unique colonne
    if df.shape[1] >= 2:
        return df.columns[-1]
    return df.columns[0]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tsv", required=True, help="Chemin du TSV d'entraînement (text\\tlabel)")
    ap.add_argument("--label-col", default=None, help="Nom explicite de la colonne des labels (sinon auto)")
    ap.add_argument("--min-labels", type=int, default=2, help="Nb. minimum de labels distincts (défaut: 2)")
    ap.add_argument("--min-per-label", type=int, default=1, help="Nb. minimum d'exemples/label (défaut: 1)")
    ap.add_argument("--sep", default="\t", help="Séparateur (défaut: TAB)")
    ap.add_argument("--quiet", action="store_true", help="Réduit la verbosité")
    args = ap.parse_args()

    try:
        df = pd.read_csv(
            args.tsv,
            sep=args.sep,
            dtype=str,
            engine="python",
            on_bad_lines="skip",
        )
    except FileNotFoundError:
        print(f"[SANITY][ERR] Fichier introuvable: {args.tsv}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"[SANITY][ERR] Lecture TSV: {e}", file=sys.stderr)
        return 2

    if df.empty:
        print("[SANITY][ERR] TSV vide.", file=sys.stderr)
        return 2

    label_col = guess_label_column(df, args.label_col)
    if label_col not in df.columns:
        print(f"[SANITY][ERR] Colonne labels introuvable. Colonnes={list(df.columns)}", file=sys.stderr)
        return 2

    labels = df[label_col].dropna()
    # Filtre éventuels labels vides/blancs
    labels = labels.map(lambda x: x.strip()).replace("", pd.NA).dropna()
    cnt = Counter(labels)

    if not args.quiet:
        print(f"[SANITY] fichier={args.tsv}")
        print(f"[SANITY] colonne_label={label_col}")
        # tri par fréquence desc
        for lab, n in cnt.most_common():
            print(f"  - {lab}: {n}")

    # Vérifs
    ok = True
    if len(cnt) < args.min_labels:
        print(f"[SANITY][FAIL] {len(cnt)} label(s) trouvé(s) < min-labels={args.min_labels}", file=sys.stderr)
        ok = False

    rare = {lab: n for lab, n in cnt.items() if n < args.min_per_label}
    if rare:
        print(f"[SANITY][WARN] Labels sous le seuil min-per-label={args.min_per_label}: {rare}", file=sys.stderr)

    if ok:
        if not args.quiet:
            print("[SANITY][OK] Conditions remplies.")
        return 0
    else:
        return 1


if __name__ == "__main__":
    sys.exit(main())

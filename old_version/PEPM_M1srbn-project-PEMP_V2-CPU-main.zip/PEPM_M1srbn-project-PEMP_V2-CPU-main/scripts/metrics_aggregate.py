#Projet PEPM By Yi Fan && Adrien
#!/usr/bin/env python3
import argparse, json, csv
from pathlib import Path

def flatten_spacy(d:dict):
    # SpaCy evaluate 3.8: on cherche des clés génériques
    out={"family":"spacy"}
    # scores possibles
    for k in ("cats_score","cats_macro_p","cats_macro_r","cats_macro_f","cats_micro_f","cats_accuracy"):
        if k in d: out[k]=d[k]
    # compat fallback
    if "cats_f_per_type" in d and "cats_macro_f" not in out:
        try:
            vals = list(d["cats_f_per_type"].values())
            out["cats_macro_f"] = sum(vals)/max(1,len(vals))
        except Exception: pass
    return out

def flatten_sklearn(d:dict):
    return {
        "family": d.get("family","sklearn"),
        "accuracy": d.get("accuracy"),
        "f1_macro": d.get("f1_macro"),
        "f1_weighted": d.get("f1_weighted"),
        "auc": d.get("auc"),
        "train_time_sec": d.get("train_time_sec"),
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reports-dir", type=Path, default=Path("reports"))
    ap.add_argument("--out-csv", type=Path, default=Path("reports/summary.csv"))
    args=ap.parse_args()

    rows=[]
    for p in sorted(args.reports_dir.glob("*.json")):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        if "spacy_version" in d or "pipeline" in d:
            flat = flatten_spacy(d); flat["file"]=p.name
            rows.append(flat)
        elif "family" in d and ("f1_macro" in d or "accuracy" in d):
            flat = flatten_sklearn(d); flat["file"]=p.name
            rows.append(flat)

    keys = sorted({k for r in rows for k in r.keys()})
    args.out_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.out_csv.open("w", encoding="utf-8", newline="") as f:
        w=csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(rows)
    print(f"[OK] summary → {args.out_csv} ({len(rows)} lignes)")

if __name__=="__main__":
    main()

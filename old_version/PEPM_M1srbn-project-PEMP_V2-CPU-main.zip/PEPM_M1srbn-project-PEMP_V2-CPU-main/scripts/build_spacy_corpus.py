#Projet PEPM By Yi Fan && Adrien
# scripts/build_spacy_corpus.py
from __future__ import annotations
import argparse
import json
import os
import random
from pathlib import Path
from typing import Dict, List

import pandas as pd
import spacy
from spacy.tokens import DocBin


def oversample(df: pd.DataFrame, label_col: str = "label", seed: int = 42) -> pd.DataFrame:
    random.seed(seed)
    counts = df[label_col].value_counts()
    max_n = counts.max()
    parts = []
    for lab, n in counts.items():
        sub = df[df[label_col] == lab]
        if n < max_n and n > 0:
            extra = sub.sample(max_n - n, replace=True, random_state=seed)
            sub = pd.concat([sub, extra], axis=0)
        parts.append(sub)
    return pd.concat(parts, axis=0).sample(frac=1.0, random_state=seed)


def limit_stratified(df: pd.DataFrame, n_rows: int, seed: int = 42, label_col: str = "label") -> pd.DataFrame:
    if n_rows <= 0 or n_rows >= len(df):
        return df
    frac = n_rows / float(len(df))
    out = df.groupby(label_col, group_keys=False).sample(frac=min(1.0, frac), random_state=seed)
    if len(out) > n_rows:
        out = out.sample(n=n_rows, random_state=seed)
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tsv", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--labels-out", type=Path, required=True)
    parser.add_argument("--lang", type=str, default="fr")
    parser.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 1) // 2 or 1))
    parser.add_argument("--batch", type=int, default=1000,
                        help="[DEPREC] Utilisé seulement si --batch-size n'est pas fourni.")
    parser.add_argument("--batch-size", type=int, default=128,
                        help="Taille de lot pour nlp.pipe (plus petit = moins de RAM).")
    parser.add_argument("--shard-size", type=int, default=25000,
                        help="Max docs par shard .spacy (0 = un seul fichier).")
    parser.add_argument("--balance", choices=["none", "oversample"], default="none")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--label-col", type=str, default="label",
                        help="Nom de la colonne label dans le TSV (ex: 'label', 'ideology', etc.).")
    parser.add_argument("--text-col", type=str, default="text",
                        help="Nom de la colonne texte dans le TSV.")
    args = parser.parse_args()

    # --- lecture TSV
    df = pd.read_csv(args.tsv, sep="\t")

    label_col = args.label_col
    text_col = args.text_col

    if text_col not in df.columns:
        for cand in ("text", "content", "body"):
            if cand in df.columns:
                text_col = cand
                break

    if label_col not in df.columns:
        for cand in (args.label_col, "label", "ideology", "party", "crawl", "category"):
            if cand in df.columns:
                label_col = cand
                break

    if text_col not in df.columns:
        raise ValueError(f"Colonne texte introuvable. Colonnes: {list(df.columns)}")
    if label_col not in df.columns:
        raise ValueError(f"Colonne label introuvable. Colonnes: {list(df.columns)}")

    if text_col != "text" or label_col != "label":
        df = df.rename(columns={text_col: "text", label_col: "label"})


    # --- limit stratifié (si demandé)
    if args.limit and args.limit > 0:
        df = limit_stratified(df, args.limit, args.seed, label_col="label")
        print(f"[INFO] TSV limité à {len(df)} lignes.")

    # --- équilibrage (optionnel)
    if args.balance == "oversample":
        df = oversample(df, "label", seed=args.seed)

    # --- labels & sorties
    labels = sorted(df["label"].astype(str).unique())
    args.labels_out.parent.mkdir(parents=True, exist_ok=True)
    Path(args.labels_out).write_text(
        json.dumps(labels, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    nlp = spacy.blank(args.lang)
    nlp.max_length = 2_000_000

    shard_size = int(getattr(args, "shard_size", 0) or 0)
    batch_size = int(getattr(args, "batch_size", 0) or getattr(args, "batch", 128) or 128)
    n_proc = max(1, int(getattr(args, "workers", 1)))

    texts = df["text"].astype(str).tolist()
    y = df["label"].astype(str).tolist()

    if shard_size > 0:
        out_dir = args.out if args.out.is_dir() else args.out.with_suffix("")
        out_dir.mkdir(parents=True, exist_ok=True)
        print(f"[INFO] Sharding activé: {shard_size} docs/shard → {out_dir}/partXXXX.spacy")
    else:
        args.out.parent.mkdir(parents=True, exist_ok=True)

    def one_hot(label: str) -> Dict[str, float]:
        d = {L: 0.0 for L in labels}
        d[label] = 1.0
        return d

    shard_idx = 0
    count_in_shard = 0
    written_docs = 0
    db = DocBin(store_user_data=False)

    for doc, lab in zip(
        nlp.pipe(texts, n_process=n_proc, batch_size=max(1, batch_size)),
        y,
    ):
        doc.cats = one_hot(lab)
        db.add(doc)
        written_docs += 1
        count_in_shard += 1

        if shard_size > 0 and count_in_shard >= shard_size:
            shard_path = out_dir / f"part{shard_idx:04d}.spacy"
            db.to_disk(shard_path)
            print(f"[OK] wrote {shard_path} ({count_in_shard} docs)")
            shard_idx += 1
            count_in_shard = 0
            db = DocBin(store_user_data=False)

    # flush final
    if shard_size > 0:
        if count_in_shard > 0:
            shard_path = out_dir / f"part{shard_idx:04d}.spacy"
            db.to_disk(shard_path)
            print(f"[OK] wrote {shard_path} ({count_in_shard} docs)")
        print(f"[OK] total docs écrits (shards): {written_docs} → {out_dir}")
    else:
        db.to_disk(args.out)
        print(f"[OK] wrote {args.out} ({written_docs} docs)")

    print(f"[OK] labels → {args.labels_out}: {labels}")


if __name__ == "__main__":
    main()

#Projet PEPM By Yi Fan && Adrien
# scripts/eval_textcat_stream.py
#!/usr/bin/env python3
import argparse, json, pandas as pd
from pathlib import Path
import spacy
from sklearn.metrics import classification_report

def iter_texts_labels(tsv_path, chunksize=1000):
    for df in pd.read_csv(tsv_path, sep="\t", chunksize=chunksize):
        for _, r in df.iterrows():
            yield str(r["text"]), str(r["label"])

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", required=True)
    p.add_argument("--tsv", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--chunksize", type=int, default=1000)
    args = p.parse_args()

    nlp = spacy.load(args.model)
    y_true, y_pred = [], []
    texts, labels = [], []
    for t, y in iter_texts_labels(args.tsv, args.chunksize):
        texts.append(t); labels.append(y)
        if len(texts) >= args.chunksize:
            for doc in nlp.pipe(texts, batch_size=64):
                y_pred.append(max(doc.cats, key=doc.cats.get))
            y_true.extend(labels); texts.clear(); labels.clear()
    if texts:
        for doc in nlp.pipe(texts, batch_size=64):
            y_pred.append(max(doc.cats, key=doc.cats.get))
        y_true.extend(labels)

    report = classification_report(y_true, y_pred, output_dict=True, zero_division=0)
    Path(args.out).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] wrote {args.out}")

if __name__ == "__main__":
    main()

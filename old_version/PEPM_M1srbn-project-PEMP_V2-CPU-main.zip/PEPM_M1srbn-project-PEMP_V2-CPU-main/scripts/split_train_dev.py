#Projet PEPM By Yi Fan && Adrien
#!/usr/bin/env python3
import argparse, csv, random
from pathlib import Path
from collections import defaultdict

def read_tsv(tsv:Path):
    with tsv.open("r", encoding="utf-8") as f:
        rdr = csv.reader(f, delimiter="\t")
        header = next(rdr, None)
        for row in rdr:
            if not row: continue
            yield row

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train-tsv", type=Path, required=True)
    ap.add_argument("--dev-ratio", type=float, default=0.1)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out-train", type=Path, required=True)
    ap.add_argument("--out-dev", type=Path, required=True)
    args=ap.parse_args()

    random.seed(args.seed)
    by_label = defaultdict(list)
    for row in read_tsv(args.train_tsv):
        if len(row)<2: continue
        by_label[row[1]].append(row)

    train_rows=[]; dev_rows=[]
    for lab,rows in by_label.items():
        random.shuffle(rows)
        k = max(1, int(len(rows)*args.dev_ratio))
        dev_rows.extend(rows[:k])
        train_rows.extend(rows[k:])

    args.out_train.parent.mkdir(parents=True, exist_ok=True)
    with args.out_train.open("w", encoding="utf-8", newline="") as f:
        w=csv.writer(f, delimiter="\t"); w.writerow(["text","label"]); w.writerows(train_rows)
    with args.out_dev.open("w", encoding="utf-8", newline="") as f:
        w=csv.writer(f, delimiter="\t"); w.writerow(["text","label"]); w.writerows(dev_rows)

    print(f"[OK] split → train={len(train_rows)} dev={len(dev_rows)}")

if __name__=="__main__":
    main()

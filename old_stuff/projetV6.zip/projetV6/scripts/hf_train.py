# scripts/hf_train.py
from __future__ import annotations
import argparse, json, os
from pathlib import Path
import pandas as pd
import torch
from transformers import (AutoTokenizer, AutoModelForSequenceClassification,
                          Trainer, TrainingArguments, DataCollatorWithPadding)
from logging_setup import get_logger
log = get_logger("spacy_train_core")  # ou "hf_train"


os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

def set_threads(n:int):
    n = max(1, n)
    try:
        torch.set_num_threads(n)
        torch.set_num_interop_threads(max(1, n//2))
    except Exception:
        pass
    # sécurités ROCm
    try:
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.backends.cuda.sdp_kernel(enable_flash=False, enable_mem_efficient=False, enable_math=True)
    except Exception:
        pass
    return n

class DS(torch.utils.data.Dataset):
    def __init__(self, df, tok, label2id, max_len):
        self.X = df["text"].astype(str).tolist()
        self.y = [label2id[s] for s in df["label"].astype(str).tolist()]
        self.tok = tok; self.max_len = max_len
    def __len__(self): return len(self.X)
    def __getitem__(self, i):
        enc = self.tok(self.X[i], truncation=True, max_length=self.max_len)
        enc["labels"] = self.y[i]
        return enc

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", type=Path, required=True)
    ap.add_argument("--eval",  type=Path, required=True)
    ap.add_argument("--model", type=str, default="camembert-base")
    ap.add_argument("--epochs", type=int, default=2)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--accum", type=int, default=1)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--max-len", type=int, default=512)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--outdir", type=Path, default=Path("models/hf_out"))
    ap.add_argument("--grad-ckpt", action="store_true")
    ap.add_argument("--precision", choices=["auto","fp32","fp16","bf16"], default="auto")
    args = ap.parse_args()

    set_threads(args.workers)
    is_gpu = torch.cuda.is_available()
    print(f"[ENV] torch={torch.__version__} | cuda={is_gpu}")
    if is_gpu:
        try: print("GPU0:", torch.cuda.get_device_name(0))
        except Exception: pass

    train_df = pd.read_csv(args.train, sep="\t")
    eval_df  = pd.read_csv(args.eval,  sep="\t")
    labels = sorted(set(train_df["label"].astype(str)) | set(eval_df["label"].astype(str)))
    label2id = {l:i for i,l in enumerate(labels)}; id2label = {i:l for l,i in label2id.items()}
    print(f"[DATA] labels={labels} | n_train={len(train_df)} | n_eval={len(eval_df)}")

    tok = AutoTokenizer.from_pretrained(args.model, use_fast=True)
    model = AutoModelForSequenceClassification.from_pretrained(
        args.model, num_labels=len(labels), id2label=id2label, label2id=label2id
    )
    if args.grad_ckpt and hasattr(model, "gradient_checkpointing_enable"):
        model.gradient_checkpointing_enable(); print("[CFG] gradient checkpointing ON")

    # précision auto → bf16 si dispo
    bf16_supported = is_gpu and getattr(torch.cuda, "is_bf16_supported", lambda: False)()
    if args.precision == "bf16":
        bf16, fp16 = True, False
    elif args.precision == "fp16":
        bf16, fp16 = False, True
    elif args.precision == "fp32":
        bf16, fp16 = False, False
    else:
        bf16, fp16 = (bf16_supported, False)
    print(f"[CFG] precision bf16={bf16} fp16={fp16}")

    ds_train = DS(train_df, tok, label2id, args.max_len)
    ds_eval  = DS(eval_df,  tok, label2id, args.max_len)
    coll = DataCollatorWithPadding(tokenizer=tok)

    args.outdir.mkdir(parents=True, exist_ok=True)
    targs = TrainingArguments(
        output_dir=str(args.outdir / "hf_runs"),
        per_device_train_batch_size=args.batch,
        per_device_eval_batch_size=args.batch,
        dataloader_num_workers=args.workers,
        dataloader_pin_memory=is_gpu,
        gradient_accumulation_steps=max(1,args.accum),
        num_train_epochs=args.epochs,
        learning_rate=args.lr,
        warmup_ratio=0.06,
        optim="adamw_torch",
        logging_strategy="steps",
        logging_steps=100, logging_first_step=True,
        save_strategy="epoch", save_total_limit=2,
        eval_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        report_to=[],
        fp16=fp16, bf16=bf16,
        gradient_checkpointing=args.grad_ckpt,
        seed=42,
    )

    trainer = Trainer(
        model=model, args=targs,
        train_dataset=ds_train, eval_dataset=ds_eval,
        tokenizer=tok, data_collator=coll
    )
    print("[RUN] training…")
    trainer.train()
    print("[RUN] done. Saving…")
    trainer.save_model(str(args.outdir / "final_model"))
    (args.outdir / "label2id.json").write_text(json.dumps(label2id, indent=2), encoding="utf-8")
    print("[OK] Saved to", args.outdir)

if __name__ == "__main__":
    main()

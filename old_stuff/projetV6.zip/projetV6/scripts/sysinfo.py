#!/usr/bin/env python3
# scripts/sysinfo.py
from __future__ import annotations
import os, platform, shutil, json

def read_meminfo():
    info = {}
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":", 1)
                info[k.strip()] = v.strip()
    except Exception:
        pass
    return info

def fmt_gb(x_bytes: float) -> str:
    try:
        return f"{x_bytes / (1024**3):.2f} GB"
    except Exception:
        return "?"

def main():
    print("=== SYSINFO ===")
    print("[OS ]", platform.platform())
    print("[PY ]", platform.python_version())
    print("[CPU]", os.cpu_count(), "cores")
    print("[ENV] OMP=%s OPENBLAS=%s MKL=%s NUMEXPR=%s" % (
        os.getenv("OMP_NUM_THREADS"),
        os.getenv("OPENBLAS_NUM_THREADS"),
        os.getenv("MKL_NUM_THREADS"),
        os.getenv("NUMEXPR_NUM_THREADS"),
    ))

    # RAM (psutil si dispo, sinon /proc/meminfo)
    try:
        import psutil  # optional
        vm = psutil.virtual_memory()
        print("[RAM] total=%s avail=%s used=%d%%" % (fmt_gb(vm.total), fmt_gb(vm.available), vm.percent))
    except Exception as e:
        mi = read_meminfo()
        tot_kb = None
        avail_kb = None
        try:
            tot_kb = float(mi.get("MemTotal", "0 kB").split()[0])
            avail_kb = float(mi.get("MemAvailable", "0 kB").split()[0])
        except Exception:
            pass
        if tot_kb is not None and avail_kb is not None:
            print("[RAM] total=%s avail=%s (psutil absent)" % (
                fmt_gb(tot_kb*1024), fmt_gb(avail_kb*1024)))
        else:
            print("[RAM] N/A (ni psutil ni /proc/meminfo lisible)")

    # Disque
    try:
        du = shutil.disk_usage(".")
        print("[DISK] used=%s / total=%s (free=%s)" % (fmt_gb(du.used), fmt_gb(du.total), fmt_gb(du.free)))
    except Exception as e:
        print("[DISK] N/A:", e)

    # Torch / GPU
    try:
        import torch
        ok = torch.cuda.is_available()
        hip = getattr(getattr(torch, "version", None), "hip", None)
        print(f"[Torch] {getattr(torch, '__version__', '?')} | cuda_visible={ok} | hip={hip}")
        if ok:
            for i in range(torch.cuda.device_count()):
                name = torch.cuda.get_device_name(i)
                try:
                    free, total = torch.cuda.mem_get_info()
                    vram = fmt_gb(total)
                except Exception:
                    vram = "?"
                print(f"  - GPU{i}: {name} | VRAM={vram}")
    except Exception as e:
        print("[Torch] not available:", e)

    # CuPy (facultatif)
    try:
        import cupy
        print("[CuPy]", cupy.__version__)
    except Exception:
        print("[CuPy] not available")

    # spaCy
    try:
        import spacy
        print("[spaCy]", spacy.__version__)
        try:
            nlp = spacy.blank("fr")
            doc = nlp("Test rapide.")
            print("[spaCy] blank fr OK | tokens:", [t.text for t in doc])
        except Exception as e:
            print("[spaCy] blank fr error:", e)
    except Exception as e:
        print("[spaCy] not available:", e)

    # Résumé court JSON (utile pour parse automatique)
    summary = {
        "python": platform.python_version(),
        "cpu_cores": os.cpu_count(),
        "env_threads": {
            "OMP": os.getenv("OMP_NUM_THREADS"),
            "OPENBLAS": os.getenv("OPENBLAS_NUM_THREADS"),
            "MKL": os.getenv("MKL_NUM_THREADS"),
            "NUMEXPR": os.getenv("NUMEXPR_NUM_THREADS"),
        },
    }
    print("[SUMMARY]", json.dumps(summary))

if __name__ == "__main__":
    main()

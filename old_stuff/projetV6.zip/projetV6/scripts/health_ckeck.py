# scripts/health_check.py
from __future__ import annotations
import argparse, subprocess, sys, tempfile, json
from pathlib import Path

def run(cmd: list[str], cwd: str | None = None) -> int:
    print("[RUN]", " ".join(cmd))
    return subprocess.call(cmd, cwd=cwd)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", type=Path, help="chemin corpus XML pour test réel")
    ap.add_argument("--limit", type=int, default=120, help="docs max pour smoke")
    ap.add_argument("--lang", default="fr")
    ap.add_argument("--model", default="camembert-base")
    args = ap.parse_args()

    tmp = Path(tempfile.mkdtemp(prefix="smoke_"))
    print("[TMP]", tmp)

    # 0) sysinfo + imports
    if run([sys.executable, "scripts/sysinfo.py"]): sys.exit(1)
    if run([sys.executable, "scripts/check_imports.py"]): sys.exit(1)

    # 1) Si corpus fourni: échantillon minimal → TSV
    if args.corpus and args.corpus.exists():
        rc = run([
            sys.executable, "scripts/tei_to_train_job.py",
            "--corpus", str(args.corpus),
            "--outdir", str(tmp / "splits"),
            "--train-prop", "0.8",
            "--label-field", "crawl",
            "--min-chars", "150",
            "--max-tokens", "400",
            "--limit", str(args.limit),
            "--procs", "2", "--seed", "42",
            "--dedup-text",
            "--balance-train", "cap_docs", "--cap-per-label", "50", "--oversample", "--offset", "0",
        ])
        if rc: sys.exit(rc)
        train_tsv = tmp / "splits" / "train.tsv"
        job_tsv   = tmp / "splits" / "job.tsv"
    else:
        # 1b) Données synthétiques → TSV
        train_tsv = tmp / "train.tsv"; job_tsv = tmp / "job.tsv"
        import pandas as pd
        texts = [f"Texte démonstration {i}" for i in range(120)]
        labs  = ["A"]*60 + ["B"]*60
        pd.DataFrame({"text":texts, "label":labs}).to_csv(train_tsv, sep="\t", index=False)
        pd.DataFrame({"text":texts[:40], "label":labs[:40]}).to_csv(job_tsv, sep="\t", index=False)

    # 2) TSV → DocBin spaCy
    if run([sys.executable, "scripts/build_spacy_corpus.py",
            "--tsv", str(train_tsv),
            "--out", str(tmp / "train.spacy"),
            "--labels-out", str(tmp / "labels.json"),
            "--lang", args.lang, "--workers", "2"]): sys.exit(1)

    if run([sys.executable, "scripts/build_spacy_corpus.py",
            "--tsv", str(job_tsv),
            "--out", str(tmp / "job.spacy"),
            "--labels-out", str(tmp / "labels.json"),
            "--lang", args.lang, "--workers", "2"]): sys.exit(1)

    # 3) spaCy CPU (1 epoch)
    out_spacy = tmp / "spacy_smoke"
    if run([sys.executable, "scripts/spacy_train_core.py",
            "--train", str(tmp / "train.spacy"),
            "--dev",   str(tmp / "job.spacy"),
            "--out",   str(out_spacy),
            "--lang", args.lang,
            "--arch", "cnn",
            "--epochs", "1",
            "--batch-start", "16", "--batch-stop", "64",
            "--eval-freq", "100",
            "--threads", "2"]): sys.exit(1)

    # 4) HF GPU (1 epoch, petit batch)
    out_hf = tmp / "hf_smoke"
    if run([sys.executable, "scripts/hf_train.py",
            "--train", str(train_tsv),
            "--eval",  str(job_tsv),
            "--model", args.model,
            "--epochs", "1", "--batch", "8", "--lr", "2e-5",
            "--max-len", "256", "--workers", "2", "--accum", "1",
            "--precision", "fp32", "--outdir", str(out_hf)]): sys.exit(1)

    print("[OK] HEALTH-CHECK PASSED")
    print(json.dumps({"tmp": str(tmp), "spacy_out": str(out_spacy), "hf_out": str(out_hf)}, indent=2))

if __name__ == "__main__":
    main()

### Log Console

```bash
python3 -m venv .venv && source .venv/bin/activate

python3 -m pip install --upgrade pip wheel setuptools
python3 -m pip install spacy pandas scikit-learn matplotlib pyyaml
python3 -m spacy download fr_core_news_sm

# (Option GPU ROCm)
python3 -m pip install --index-url https://download.pytorch.org/whl/rocm6.0 torch torchvision
python3 -m pip install spacy-transformers transformers

python3 -m pip install --upgrade pip wheel setuptools
python3 -m pip install spacy pandas scikit-learn matplotlib pyyaml
python3 -m spacy download fr_core_news_sm

# (Option GPU ROCm)
python3 -m pip install --index-url https://download.pytorch.org/whl/rocm6.0 torch torchvision
python3 -m pip install spacy-transformers transformers

.venv) teas@teas-ms7d42:~/prog/projet methodo/projetV5$ MEM=24G; SWAP=6G; CPUQ=220; CORES=0-19
systemd-run --user --scope \
  -p MemoryMax=$MEM -p MemorySwapMax=$SWAP -p CPUQuota=${CPUQ}% \
  bash -lc 'export OMP_NUM_THREADS=20 OPENBLAS_NUM_THREADS=20 MKL_NUM_THREADS=20 NUMEXPR_NUM_THREADS=20 MALLOC_ARENA_MAX=2; \
            taskset -c '"$CORES"' make quick'
Running as unit: run-r528509c7654943878405ef58a78ad9b0.scope; invocation ID: 51f70eee146c4c869b326d3752887b4a
python3 scripts/tei_to_train_job.py \
  --corpus data/raw/corpus/corpus.xml \
  --outdir data/interim/splits_try \
  --train-prop 0.8 \
  --label-field crawl \
  --min-chars 200 \
  --max-tokens 600 \
  --limit 25000 \
  --procs 20 --seed 42 \
  --dedup-text \
  --balance-train cap_docs --cap-per-label 5000 --oversample --offset 0
[INFO] Collectés: 255022 TEI docs → multiprocessing 20 procs (chunksize=128)
[INFO] Limité à 25000 docs (mode essai).
[INFO] Dédup texte: 25000 → 24998 docs (par MD5).
[INFO] Docs: 24998 | Labels: 4 | Top:
  - crawl-contretemps-20250928_003525: 19142
  - crawl-initiative-communiste-20250928_003234: 5017
  - crawl-eco-full-20250928_000354: 676
  - crawl-cce-full-20250927_234505: 163
[INFO] Split → Train=19999 | Job=4999
[INFO] Balance TRAIN=cap_docs(cap=5000, oversample=True, offset=0): 19999 → 20000 docs
[STATS] TRAIN: 20000 docs
  - crawl-cce-full-20250927_234505: 5000 (25.0%)
  - crawl-contretemps-20250928_003525: 5000 (25.0%)
  - crawl-eco-full-20250928_000354: 5000 (25.0%)
  - crawl-initiative-communiste-20250928_003234: 5000 (25.0%)
[STATS] JOB: 4999 docs
  - crawl-contretemps-20250928_003525: 3828 (76.6%)
  - crawl-initiative-communiste-20250928_003234: 1003 (20.1%)
  - crawl-eco-full-20250928_000354: 135 (2.7%)
  - crawl-cce-full-20250927_234505: 33 (0.7%)
[OK] TSV → data/interim/splits_try/train.tsv ; data/interim/splits_try/job.tsv  (balance=cap_docs(cap=5000, oversample=True, offset=0))
[OK] XML → data/interim/splits_try/corpus_train.xml ; data/interim/splits_try/corpus_job.xml
python3 scripts/build_spacy_corpus.py \
  --tsv data/interim/splits_try/train.tsv \
  --out data/processed/spacy/train_try.spacy \
  --labels-out data/processed/spacy/labels_try.json \
  --lang fr --workers 20


# 18 coeurs logiques = 1800%
MEM=20G; SWAP=4G; CPUQ=1800; CORES=0-17
systemd-run --user --scope \
  -p MemoryMax=$MEM -p MemorySwapMax=$SWAP -p CPUQuota=${CPUQ}% -p AllowedCPUs=$CORES \
  bash -lc 'export OMP_NUM_THREADS=18 OPENBLAS_NUM_THREADS=18 MKL_NUM_THREADS=18 NUMEXPR_NUM_THREADS=18 MALLOC_ARENA_MAX=2;
            taskset -c '"$CORES"' make quick_capdocs THREADS=18 NPROC=18'

```
